#recodage et labelisations des variables 

library(dplyr)
library(expss)



#recodage des variables

Base_tp2$sexe <- as.character(Base_tp2$sexe)# a executer premierment: pour changer le type de données en caractere
Base_tp2 <- Base_tp2 %>%
  mutate(sexe = case_when(
    sexe == "1" ~ "Homme",
    sexe == "2" ~ "Femme",
    TRUE ~ sexe  # Garder les autres valeurs inchangées
  ))# ensuite executer cela
#concersion en character pour les stat descriptives
Base_tp2$sexe = as.character(Base_tp2$sexe)


Base_tp2$sit_mat <- as.character(Base_tp2$sit_mat)
# Recoder la variable "sit_mat" avec des libellés complexes en utilisant case_when() de dplyr
Base_tp2 <- Base_tp2 %>%
  mutate(sit_mat = case_when(
    sit_mat == "1" ~ "Marié(e)",
    sit_mat == "3" ~ "Veuf(ve)",
    sit_mat == "4" ~ "Divorcé(e)",
    sit_mat == "5" ~ "Séparé(e)",
    sit_mat == "6" ~ "Célibataire",
    TRUE ~ sit_mat  # Garder les autres valeurs inchangées
  ))


Base_tp2$si_chef_men <- as.character(Base_tp2$si_chef_men)
Base_tp2 <- Base_tp2 %>%
  mutate(si_chef_men = case_when(si_chef_men == "1" ~ "femme du chef de menage",
                                 si_chef_men == "2" ~ "chef de menage",
                                 si_chef_men =="3" ~ "fils-fille du chef de menage",
                                 si_chef_men == "99" ~  "Autres" , 
                                 TRUE~ si_chef_men))
                                           

Base_tp2$ethnie <- as.character(Base_tp2$ethnie)
Base_tp2 <- Base_tp2 %>%
  mutate(ethnie = case_when(ethnie ==  "1" ~ "Wolof",
                            ethnie == "2" ~ "Pularr/Toucouleur",
                            ethnie ==  "3" ~ "Sérère",
                            ethnie =="4" ~ "Mandika/bambara",
                            ethnie == "5" ~ "Soninké",
                            ethnie =="6" ~ "Diola",
                            ethnie == "7" ~ "Mandjak",
                            ethnie ==  "8" ~ "Bainouk",
                            ethnie == "9" ~ "Maures",
                            ethnie == "10" ~ "Balante",
                            ethnie =="77" ~ "Autre",
                            TRUE~ethnie))


Base_tp2$occupation <- as.character(Base_tp2$occupation)
Base_tp2 <- Base_tp2 %>%
mutate(occupation = case_when(occupation=="1" ~ "Agriculture,Elevage,Sylviculture,Peche",
                              occupation==  "2" ~ "Activité extractive",
                              occupation== "3" ~ "Activité de fabrication(Artisanat)",
                              occupation== "4" ~ "Activité de transformation",
                              occupation== "5" ~ "Production et distribution d'electricité et de gaz",
                              occupation== "6" ~ "Production et distribution d'eau,assainissement, 
                                            Traitement des dechets et pollution",
                                                  TRUE ~ occupation))



Base_tp2$formation <- as.character(Base_tp2$formation)
Base_tp2 <- Base_tp2 %>%
  mutate(formation = case_when(formation=="1" ~ "Non scolarisé",
                               formation=="2" ~ "Elémentaire",
                               formation=="3" ~ "Moyen",
                               formation=="4" ~ "Secondaire",
                               formation=="5" ~ "Licence",
                               formation=="6" ~ "Master",
                               formation=="7" ~ "Doctorat",
                               formation=="99" ~ "Ne sait pas",
                               TRUE~ formation))



Base_tp2$niveau_alphabs <- as.character(Base_tp2$niveau_alphabs)
Base_tp2 <- Base_tp2 %>%
  mutate(niveau_alphabs = case_when(niveau_alphabs =="0" ~ "Sans niveau",
                                    niveau_alphabs =="1" ~ "Sait lire dans une langue",
                                    niveau_alphabs =="2" ~ "Sait lire et ecrire dans une langue" , 
                                    TRUE~ niveau_alphabs))
                              

Base_tp2$types_varietes <- as.character(Base_tp2$types_varietes)
Base_tp2 <- Base_tp2 %>%
  mutate(types_varietes = case_when(types_varietes =="1" ~ "Traditionnelles",
                                    types_varietes=="2" ~ "Ameliorées", 
                                    TRUE~ types_varietes))


Base_tp2$criteres_var <- as.character(Base_tp2$criteres_var)
Base_tp2 <- Base_tp2 %>%
  mutate(criteres_var = case_when(criteres_var =="1" ~ "Rendements élévée",
                                  criteres_var =="2" ~ "taille des graines",
                                  criteres_var =="3" ~ "Resistence aux maladies/ravageurs",
                                  criteres_var =="4" ~ "tolerantes aux secheresses",
                                  criteres_var =="5" ~ "tolerantes aux innovations",
                                  criteres_var =="6" ~ "Faible charge de Travail",
                                  criteres_var =="7" ~ "Faibles quantités d'intrants",
                                  criteres_var =="8" ~ "facile à transformer", 
                                  criteres_var =="9" ~ "Haute teneur en huiler",
                                  criteres_var =="10" ~ "Haut rendement apres transformation",
                                  criteres_var =="11" ~ "Demande sur le marché",
                                  criteres_var =="12" ~ "Bon gout",
                                  criteres_var =="13" ~ "Belle couleur",
                                  criteres_var =="14" ~ "Haut rendement en fourrage",
                                  criteres_var =="15" ~ "Qualité du fourrage",
                                  criteres_var =="16" ~ "Autres à preciser",
                                    TRUE~ criteres_var))




#labelisation


Base_tp2 <- Base_tp2 %>%
  apply_labels(sexe = "Sexe ",
               age = "Age",
               sit_mat = "Situation matrimoniale",
               si_chef_men = "Statut dans le menage",
               ethnie = "Ethnie",
               occupation = "Occupation",
               formation = "Formation",
               niveau_alphabs = "Niveau d'alphabetisation",
               types_varietes = "Qu'elles sont les variétés que vous utilisezpour la production de sesame ?")



# atraiter la partie des var_crtieres
         

Base_tp2$sexe <- as.character(Base_tp2$sit_mat)

