#importation de la base de donnée et mise en forme

library(readxl)
Base_tp2 <- read_excel("Donnee/Base TP2.xlsx")
View(Base_tp2)

#donnons le nombre de ligne et de colonnes de ce dataframe

n_ligne <- nrow(Base_tp2)
paste0("le nombre de ligne est" , n_ligne)

#donnons le nombre de l colonnes de ce dataframe

n_colonnes <- ncol(Base_tp2)
paste0("le nombre de colonne est" , n_colonnes)


