library(ggplot2)

bivarie2 <- function(variable_x, variable_y, base_de_donnees = NULL, graphique = TRUE) {
  # Vérifier si la base de données est spécifiée
  if (!is.null(base_de_donnees)) {
    variable_x <- base_de_donnees[[deparse(substitute(variable_x))]]
    variable_y <- base_de_donnees[[deparse(substitute(variable_y))]]
  }
  
  # Convertir les variables en facteur si elles ne le sont pas déjà
  variable_x <- factor(variable_x)
  variable_y <- factor(variable_y)
  
  # Calculer le tableau croisé des fréquences absolues
  freq_table <- table(variable_x, variable_y)
  
  # Créer le tableau de distribution
  tableau <- as.data.frame(freq_table)
  colnames(tableau) <- c("Variable X", "Variable Y", "Effectif")
  
  # Créer le graphique avec ggplot2 si graphique est TRUE
  if (graphique) {
    plot <- ggplot(data = tableau, aes(x = as.factor(`Variable X`), y = as.factor(`Variable Y`), fill = as.factor(`Effectif`))) +
      geom_tile() +
      labs(title = "Heatmap des fréquences absolues", x = "Variable X", y = "Variable Y") +
      theme(axis.text.x = element_text(angle = 45, hjust = 1))  # Rotation des étiquettes x
    print(plot)
  }
  
  # Retourner le tableau de distribution
  return(tableau)
}


bivarie2(sexe, region, base_de_donnees = Base_tp2 , graphique = TRUE)
