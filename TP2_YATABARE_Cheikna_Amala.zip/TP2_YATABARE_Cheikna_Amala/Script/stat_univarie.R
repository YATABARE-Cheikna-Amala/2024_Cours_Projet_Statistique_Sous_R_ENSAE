library(ggplot2)

univarie <- function(variable, base_de_donnees = NULL, graphique = TRUE) {
  # Vérifier si la base de données est spécifiée
  if (!is.null(base_de_donnees)) {
    variable <- base_de_donnees[[deparse(substitute(variable))]]
  }
  
  # Convertir la variable en facteur si elle ne l'est pas déjà
  variable <- factor(variable)
  
  # Calculer la fréquence absolue
  freq_absolue <- table(variable)
  
  # Calculer la fréquence relative avec deux chiffres après la virgule
  freq_relative <- round(prop.table(freq_absolue), 2)
  
  # Créer le tableau de distribution sans inclure le total dans le graphique
  tableau <- data.frame(Modalités = as.character(names(freq_absolue)),
                        Effectif = as.numeric(as.vector(freq_absolue)),
                        Fréquence = as.numeric(as.vector(freq_relative)))
  # Calculer le total des fréquences absolues
  total_freq_absolue <- sum(as.numeric(tableau$Effectif))
  
  # Ajouter la ligne du total
  total_row <- c("Total", total_freq_absolue, 1)
  tableau <- rbind(tableau, total_row)
  
  
  # Retirer la ligne du total du tableau pour l'affichage du graphique
  tableau_graphique <- subset(tableau, Modalités != "Total")
  
  # Créer le graphique avec ggplot2 si display_plot est TRUE
  if (graphique) {
    plot <- ggplot(data = tableau_graphique, aes(x = Modalités, y = Effectif, fill = Modalités)) +
      geom_bar(stat = "identity") +
      labs(title = "Graphique des fréquences absolues", x = "Modalités", y = "Effectif") +
      theme(axis.text.x = element_text(angle = 45, hjust = 1))  # Rotation des étiquettes x
    print(plot)
  }
  
  # Retourner le tableau de distribution incluant le total
  return(tableau)
}

